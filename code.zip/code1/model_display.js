
import * as THREE from 'https://cdn.skypack.dev/three@0.129.0/build/three.module.js';
import { OrbitControls } from 'https://cdn.skypack.dev/three@0.129.0/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'https://cdn.skypack.dev/three@0.129.0/examples/jsm/loaders/GLTFLoader.js';

// Create a scene
var scene = new THREE.Scene();

// Create a camera
var camera = new THREE.PerspectiveCamera(80, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.z = 10;

// Create a renderer
var renderer = new THREE.WebGLRenderer( { antialias: true } );
renderer.setSize(window.innerWidth, window.innerHeight);
document.getElementById('model-container').appendChild(renderer.domElement);

document.addEventListener('DOMContentLoaded', function(){
    if (GLTFLoader) {
        const loader = new GLTFLoader()
        loader.load(document.getElementById('model-name').getAttribute('url'), function (gltf){
            gltf.scene.position.set(0, 0, 0);
            gltf.scene.scale.set(1, 1, 1);
            
            scene.add(gltf.scene);
            // Adjust camera position based on the model's size and position
            var box = new THREE.Box3().setFromObject(gltf.scene);
            var center = box.getCenter(new THREE.Vector3());
            
            controls.target = center; // Set the camera target to the center of the model
            camera.position.set(center.x, center.y, center.z + box.getSize(new THREE.Vector3()).length()); // Adjust camera position
    
            animate();
            
    });
    } else {
        console.error('GLTFLoader not found. Make sure it is loaded.');
    }
})


var ambientLight = new THREE.AmbientLight(0xffffff, 1);
scene.add(ambientLight);

// var directionalLight = new THREE.DirectionalLight(0xffffff, 1);
// scene.add(directionalLight);

// Add mouse controls for rotation
var controls = new OrbitControls(camera, renderer.domElement);
controls.maxPolarAngle = Math.PI / 2;

// Render the scene
var animate = function () {
    requestAnimationFrame(animate);

    // Update controls
    controls.update();
    controls.autoRotate = true;
    
    // Render the scene
    renderer.setClearColor(0xffffff, 1)
    renderer.render(scene, camera);
}

// Handle window resize
window.addEventListener('resize', function () {
    var newWidth = window.innerWidth;
    var newHeight = window.innerHeight;

    camera.aspect = newWidth / newHeight;
    camera.updateProjectionMatrix();

    renderer.setSize(newWidth, newHeight);
});

// Start the animation
animate();

